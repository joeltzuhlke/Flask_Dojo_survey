from flask import Flask, render_template, request, redirect, flash, session
app = Flask(__name__)
app.secret_key ="sKey"
@app.route('/')
def index():
    return render_template('index.html')
@app.route('/process', methods =['POST'])
def output():
    name = request.form['name']
    location = request.form['location']
    language = request.form['language']
    comment = request.form['comment']
    if len(name)<1 or len(comment)<1 or len(comment)>120:
        if len(name)<1:
            flash("Name cannot be empty")
        if len(comment)<1:
            flash("You must have something to say, put something in the comment box")
        if len(comment)>120:
            flash("No one wants to read that much, shorten your comment windbag!")
        return redirect ('/')
    else:
        return render_template('output.html', NA=name, com=comment, lan=language, loc=location)
app.run(debug=True)